<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vogue & Chic - About</title>
    <!-- Link to your existing CSS file -->
    <link rel="stylesheet" href="Styles.css">
</head>
<body>

    <!-- Header Section (Matches the dark teal top bar) -->
    <header class="top-bar">
        <div class="logo"><a href="HOME.php" class="logo-link">Vogue & Chic</a></div>
    </header>

    <!-- Main Content Area -->
    <main>

        <!-- About Text Section (Light teal background) -->
        <section class="about-section">
            <h2 class="section-title">ABOUT</h2>
            <p class="about-description">
                Welcome to Vogue & Chic where style meets substance. We believe getting dressed should feel effortless, which is why we design clothing that balances timeless design with modern comfort. Every piece in our collection is thoughtfully crafted from quality materials, made to fit real bodies and real lives, whether you're dressing for work, the weekend, or everything in between. We're committed to responsible production and transparent practices, because looking good shouldn't come at the cost of feeling good about how your clothes are made. More than a brand, we're building a community of people who value confidence, authenticity, and pieces they'll reach for again and again.
            </p>
        </section>

        <!-- Hero Image Section (Beach scene) -->
        <section class="image-section">
            <!-- Replace the src URL below with your actual image file path if you have it locally -->
            <img src="https://images.unsplash.com/photo-1519046904884-53103b34b206?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80" alt="Two children standing on a beach looking at the ocean">
        </section>

    </main>

</body>
</html>