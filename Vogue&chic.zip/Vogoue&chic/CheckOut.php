<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout | Vogue and Chic Boutique</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Alike&display=swap">
    <link rel="stylesheet" href="Styles.css">

   </head>

<body class="login-page">

<main class="login-card">

    <header class="brand">
        <h1><a href="HOME.php" class="logo-link">Vogue <span>&amp;</span> Chic</a></h1>
        <h2 class="page-title">checkout</h2>

        <h2 class="welcome">Welcome,
            <?= htmlspecialchars($_SESSION['user_name'] ?? 'Customer', ENT_QUOTES, 'UTF-8') ?>
        </h2>
        <p class="intro">Please enter your shipping details</p>
    </header>

    <!-- novalidate: the script below shows our own error messages -->
    <form action="save_order.php" method="POST" id="checkout_form" novalidate>
        <input type="hidden" name="csrf_token"
               value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">

        <div class="form-group">
            <label for="full_name">Full Name</label>
            <input type="text" id="full_name" name="full_name"
                   maxlength="100" autocomplete="name" required>
        </div>

        <div class="form-group">
            <label for="phone">Phone Number</label>
            <input type="tel" id="phone" name="phone"
                   maxlength="30" autocomplete="tel" required>
        </div>

        <div class="form-group">
            <label for="address">Shipping Address</label>
            <input type="text" id="address" name="address"
                   maxlength="255" autocomplete="street-address" required>
        </div>

        <div class="form-group">
            <label for="city">City or Town</label>
            <input type="text" id="city" name="city"
                   maxlength="100" autocomplete="address-level2" required>
        </div>

        <div class="form-group">
            <label for="postal_code">Postal code</label>
            <input type="text" id="postal_code" name="postal_code"
                   maxlength="20" autocomplete="postal-code" required>
        </div>

        <div class="form-group">
            <label for="payment_method">Payment method</label>
            <select id="payment_method" name="payment_method" required>
                <option value="">Choose a payment method</option>
                <option value="cod">Cash on Delivery</option>
                <option value="card">Card Payment</option>
            </select>
        </div>

        <!-- Card details (shown only for Card Payment).
             These inputs have no name attribute, so the browser does NOT
             send them to save_order.php. -->
        <div class="card-details" id="card_details">
            <h3>Card details</h3>

            <div class="form-group">
                <label for="card_name">Name on card</label>
                <input type="text" id="card_name" maxlength="100"
                       autocomplete="cc-name" placeholder="As shown on your card">
            </div>

            <div class="form-group">
                <label for="card_number">Card number</label>
                <input type="text" id="card_number" maxlength="19"
                       inputmode="numeric" autocomplete="cc-number"
                       placeholder="1234 5678 9012 3456">
            </div>

            <div class="card-row">
                <div class="form-group">
                    <label for="card_expiry">Expiry date</label>
                    <input type="text" id="card_expiry" maxlength="5"
                           inputmode="numeric" autocomplete="cc-exp"
                           placeholder="MM/YY">
                </div>
                <div class="form-group">
                    <label for="card_cvv">CVV</label>
                    <input type="password" id="card_cvv" maxlength="4"
                           inputmode="numeric" autocomplete="cc-csc"
                           placeholder="123">
                </div>
            </div>

            <p class="secure-note">Your card details are entered securely.</p>
        </div>

        <button type="submit" class="login-btn">Place order</button>
    </form>

</main>

<script>
    const form = document.getElementById('checkout_form');

    // Letters (including accents), spaces, apostrophe, dot and hyphen only
    const lettersOnly = /^[A-Za-zÀ-ÿ\s'.\-]+$/;

    /* ---------- Validation rules: return an error message, or '' if OK ---------- */
    const rules = {
        full_name: v =>
            !v ? 'Please enter your full name.' :
            !lettersOnly.test(v) ? 'Name can only contain letters, no numbers.' : '',

        phone: v => {
            if (!v) return 'Please enter your phone number.';
            if (!/^[0-9+\s()\-]+$/.test(v)) return 'Phone number can only contain digits, not letters.';
            const count = v.replace(/\D/g, '').length;
            return (count < 7 || count > 15) ? 'Enter a valid phone number (7 to 15 digits).' : '';
        },

        address: v => !v ? 'Please enter your shipping address.' : '',

        city: v =>
            !v ? 'Please enter your city or town.' :
            !lettersOnly.test(v) ? 'City can only contain letters, no numbers.' : '',

        postal_code: v =>
            !v ? 'Please enter your postal code.' :
            !/^[A-Za-z0-9\s\-]+$/.test(v) ? 'Postal code can only contain letters and numbers.' : '',

        payment_method: v => !v ? 'Please choose a payment method.' : '',

        card_name: v =>
            !v ? 'Please enter the name on the card.' :
            !lettersOnly.test(v) ? 'Name can only contain letters, no numbers.' : '',

        card_number: v => {
            const digits = v.replace(/\s/g, '');
            if (!digits) return 'Please enter your card number.';
            return (digits.length < 13 || digits.length > 16) ? 'Card number must be 13 to 16 digits.' : '';
        },

        card_expiry: v => {
            if (!v) return 'Please enter the expiry date.';
            if (!/^(0[1-9]|1[0-2])\/\d{2}$/.test(v)) return 'Use the format MM/YY (for example 08/28).';
            const month = parseInt(v.slice(0, 2), 10);
            const year  = 2000 + parseInt(v.slice(3), 10);
            const now   = new Date();
            const expired = year < now.getFullYear() ||
                            (year === now.getFullYear() && month < now.getMonth() + 1);
            return expired ? 'This card has expired.' : '';
        },

        card_cvv: v =>
            !v ? 'Please enter the CVV.' :
            !/^\d{3,4}$/.test(v) ? 'CVV must be 3 or 4 digits.' : ''
    };

    /* ---------- Create an empty error line under every field ---------- */
    Object.keys(rules).forEach(id => {
        const field = document.getElementById(id);
        const msg = document.createElement('span');
        msg.className = 'error';
        msg.id = id + '_error';
        msg.hidden = true;
        field.after(msg);
    });

    function showError(id, message) {
        const field = document.getElementById(id);
        const msg = document.getElementById(id + '_error');
        msg.textContent = message;
        msg.hidden = !message;
        field.classList.toggle('invalid', !!message);
    }

    // Returns true when the field is valid
    function validate(id) {
        const field = document.getElementById(id);
        if (field.disabled) return true;
        const message = rules[id](field.value.trim());
        showError(id, message);
        return !message;
    }

    /* ---------- Live checking while typing ---------- */
    const filtered = ['card_number', 'card_expiry', 'card_cvv']; // handled separately below

    Object.keys(rules).forEach(id => {
        const field = document.getElementById(id);

        // Check while typing, but do not nag about an empty field until submit
        if (!filtered.includes(id)) {
            const event = field.tagName === 'SELECT' ? 'change' : 'input';
            field.addEventListener(event, () => {
                if (field.value.trim() === '' && field.tagName !== 'SELECT') {
                    showError(id, '');
                } else {
                    validate(id);
                }
            });
        }
        // Full check when leaving the field
        field.addEventListener('blur', () => {
            if (field.value.trim() !== '') validate(id);
        });
    });

    /* ---------- Card fields: remove wrong characters and show an error ---------- */
    function digitsOnlyField(id, allowed, message, format) {
        document.getElementById(id).addEventListener('input', function () {
            const hadBadChars = !allowed.test(this.value);
            const digits = this.value.replace(/\D/g, '');
            this.value = format(digits);
            showError(id, hadBadChars ? message : '');
        });
    }

    digitsOnlyField('card_number', /^[0-9\s]*$/,
        'Card number can only contain digits, not letters.',
        d => d.slice(0, 16).replace(/(.{4})/g, '$1 ').trim());

    digitsOnlyField('card_expiry', /^[0-9\/]*$/,
        'Expiry date can only contain digits.',
        d => d.length >= 3 ? d.slice(0, 2) + '/' + d.slice(2, 4) : d.slice(0, 4));

    digitsOnlyField('card_cvv', /^[0-9]*$/,
        'CVV can only contain digits, not letters.',
        d => d.slice(0, 4));

    /* ---------- Show / hide the card section ---------- */
    const payment = document.getElementById('payment_method');
    const box = document.getElementById('card_details');
    const cardIds = ['card_name', 'card_number', 'card_expiry', 'card_cvv'];

    function toggleCardDetails() {
        const isCard = payment.value === 'card';
        box.classList.toggle('show', isCard);
        cardIds.forEach(id => {
            const field = document.getElementById(id);
            field.disabled = !isCard;
            if (!isCard) showError(id, '');
        });
    }
    payment.addEventListener('change', toggleCardDetails);
    toggleCardDetails();

    /* ---------- On submit: check everything, stop if there is an error ---------- */
    form.addEventListener('submit', function (e) {
        let firstBad = null;
        Object.keys(rules).forEach(id => {
            if (!validate(id) && !firstBad) firstBad = document.getElementById(id);
        });
        if (firstBad) {
            e.preventDefault();
            firstBad.focus();
        }
    });
</script>

</body>
</html>