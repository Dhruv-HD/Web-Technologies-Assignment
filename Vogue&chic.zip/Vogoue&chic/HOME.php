<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Vogue & Chic</title>
<link rel="stylesheet" href="Styles.css">
</head>
<body class="home-page">

  <div class="home">

    <!-- Header: row 1 = logo + links, row 2 = search + icons under HELP -->
    <header class="card-header home-header">
      <div class="home-top">
        <div class="home-logo">Vogue &amp; Chic</div>
        <nav class="home-nav">
          <a href="About.php">ABOUT</a>
          <a href="#">REVIEW</a>
          <a href="Help.php">HELP</a>
        </nav>
      </div>

      <div class="home-bar">
        <div class="search-bar">
          <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg>
          <input type="text" placeholder="Search here...">
        </div>
        <div class="home-icons">
          <a href="Login.php" aria-label="Account">
            <svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-8 8-8s8 3.6 8 8"/></svg>
          </a>
          <a href="view_cart.php" aria-label="Cart">
            <svg viewBox="0 0 24 24"><path d="M6 7h12l1 14H5L6 7z"/><path d="M9 7a3 3 0 0 1 6 0"/></svg>
          </a>
        </div>
      </div>
    </header>

    <!-- Hero -->
    <section class="hero">
      <h1>New Collection</h1>

      <div class="hero-grid">
        <div class="hero-left">
          <div class="season">SUMMER 2026</div>
          <!-- Put the image link in place of # -->
          <img class="img-box img-man" src="https://cdn.discordapp.com/attachments/1565465227926044712/1565660951976349736/image.png?ex=6ae5b6e3&is=6ae46563&hm=6c060b4179983b5b69fe0c68c88ffa18396eef6daa1482207ce1b61f8652fab4&">
          <p class="about-text">
            Discover a world where fashion meets individually. At <span class="brand">Vogue &amp; Chic</span>,
            we craft timeless designs that celebrate your unique personality.
          </p>
        </div>
        <!-- Put the image link in place of # -->
        <img class="img-box img-woman" src="https://cdn.discordapp.com/attachments/1565465227926044712/1565660580285653033/image.png?ex=6ae5b68a&is=6ae4650a&hm=aec01c8d7a6b168f9b78bd90acc2f09d86460ffe5367d8caf98b3f229617101a&">
      </div>
    </section>

    <hr class="divider">

    <!-- Trending (put each image link in place of #) -->

    <section class="trending">
      <h2>Trending Now</h2>
      <div class="grid">
        <a href="Item1.php" class="card">
          <img class="img-box" src="https://cdn.discordapp.com/attachments/1565465227926044712/1565471405879853247/image.png?ex=6ae5065c&is=6ae3b4dc&hm=e08d7c26502ccde4ea8166c3d0bc0fdc9ba1c90a36caf0ea28b70e06a6b6f5bd&">
          <div class="label">Classic Denim Jacket<br>Rs. 2500</div>
        </a>
        <a href="Item2.php" class="card">
          <img class="img-box" src="https://cdn.discordapp.com/attachments/1565465227926044712/1565474239417683978/image.png?ex=6ae508ff&is=6ae3b77f&hm=98b95e5d66c836c25827c189e424ddded7180d2ab17f6fc63a0f4f219b1f73c6&">
          <div class="label">Men's Knit Short Sleeve Shirt<br>Rs. 1200</div>
        </a>
        <a href="Item3.php" class="card">
          <img class="img-box" src="https://cdn.discordapp.com/attachments/1565465227926044712/1565472665983258804/image.png?ex=6ae5b048&is=6ae45ec8&hm=5283b9fc529804d9671c809651bf1aadeaebac75fbaaea2de087044c14a213ff&">
          <div class="label">Women's Maxi Dress<br>Rs. 1150</div>
        </a>
        <a href="Item4.php" class="card">
          <img class="img-box" src="https://cdn.discordapp.com/attachments/1565465227926044712/1565475675660488776/image.png?ex=6ae5b316&is=6ae46196&hm=dbe6f34cf91c4cccc0d43e27193e1f8bd69c1188a6defe591a823267d1269e88&">
          <div class="label">Men's Linen Shorts<br>Rs. 600</div>
        </a>
        <a href="Item5.php" class="card">
          <img class="img-box" src="https://cdn.discordapp.com/attachments/1565465227926044712/1565476428999303248/image.png?ex=6ae50b09&is=6ae3b989&hm=3a16a6d354d0f75ab3d64cd9d5cd6cc3da7cb83e39c5535d976faca41011cbd0&">
          <div class="label">Men's Long Sleeve Shirt<br>Rs. 800</div>
        </a>
        <a href="Item6.php" class="card">
          <img class="img-box" src="https://cdn.discordapp.com/attachments/1565465227926044712/1565476661892227092/image.png?ex=6ae50b41&is=6ae3b9c1&hm=2ce015910b4b5745d30beff97e578cbbb6a24c30ac709b42b07abdec8b50a314&">
          <div class="label">Cargo Pants For Summer<br>Rs. 700</div>
        </a>
      </div>
    </section>

  </div>

</body>
</html>