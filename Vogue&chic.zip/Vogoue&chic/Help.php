<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vogue & Chic Contact</title>
    <link rel="stylesheet" href="Styles.css">
</head>
<body>

    <!-- Header Section -->

    <header class="top-bar">
       <div class="logo"><a href="HOME.php" class="logo-link">Vogue & Chic</a></div>
    </header>

    <!-- Hero Image Section -->
    <section class="hero-section">
        <img src="https://images.unsplash.com/photo-1507525428034-b723cf961d3e?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80" >
    </section>

    <!-- Banner Section -->
    <section class="contact-banner">
        <h1>GET IN CONTACT WITH US!</h1>
    </section>

    <!-- Spacer Section -->
    <div class="spacer-block"></div>

    <!-- Main Form Section -->
    <main class="form-section">
        <form id="contactForm" action="#" method="post" novalidate>

            <!-- Name Field -->
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" id="name" name="name">
                <span class="error-message" id="nameError"></span>
            </div>

            <!-- Email Field -->
            <div class="form-group">
                <label for="email">E mail</label>
                <input type="email" id="email" name="email">
                <span class="error-message" id="emailError"></span>
            </div>

            <!-- Message Field -->
            <div class="form-group">
                <label for="message">Message</label>
                <textarea id="message" name="message" rows="6"></textarea>
                <span class="error-message" id="messageError"></span>
            </div>

            <!-- Submit Button -->
            <div class="form-group submit-container">
                <button type="submit">SUBMIT</button>
            </div>

        </form>
    </main>

    <!-- Footer Section -->
    <footer class="footer-section">
        <!-- Footer content would go here -->
    </footer>

    <!-- JavaScript Validation -->
    <script>
        document.getElementById('contactForm').addEventListener('submit', function(event) {
            event.preventDefault();

            // Get form fields
            const name = document.getElementById('name');
            const email = document.getElementById('email');
            const message = document.getElementById('message');

            // Get error message spans
            const nameError = document.getElementById('nameError');
            const emailError = document.getElementById('emailError');
            const messageError = document.getElementById('messageError');

            // Reset error messages and styles
            nameError.textContent = '';
            emailError.textContent = '';
            messageError.textContent = '';
            name.style.borderColor = '#ccc';
            email.style.borderColor = '#ccc';
            message.style.borderColor = '#ccc';

            let isValid = true;

            // --- NAME VALIDATION ---
            const nameValue = name.value.trim();
            // Regular expression: Only allows letters (a-z, A-Z) and spaces
            const alphabetOnly = /^[A-Za-z\s]+$/;

            if (nameValue === '') {
                nameError.textContent = 'Name cannot be empty.';
                name.style.borderColor = 'red';
                isValid = false;
            } else if (!alphabetOnly.test(nameValue)) {
                nameError.textContent = 'Name must contain only alphabetic characters.';
                name.style.borderColor = 'red';
                isValid = false;
            }

            // --- EMAIL VALIDATION ---
            if (email.value.trim() === '') {
                emailError.textContent = 'E-mail cannot be empty.';
                email.style.borderColor = 'red';
                isValid = false;
            } else if (!isValidEmail(email.value)) {
                emailError.textContent = 'Please enter a valid email address.';
                email.style.borderColor = 'red';
                isValid = false;
            }

            // --- MESSAGE VALIDATION ---
            if (message.value.trim() === '') {
                messageError.textContent = 'Message cannot be empty.';
                message.style.borderColor = 'red';
                isValid = false;
            }

            // If everything is valid
            if (isValid) {
                alert('Form submitted successfully!');
                // this.submit();
            }
        });

        // Helper function to validate email format
        function isValidEmail(email) {
            const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return re.test(String(email).toLowerCase());
        }
    </script>

</body>
</html>