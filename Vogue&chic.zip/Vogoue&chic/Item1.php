<?php
session_start();
require 'config.php';
?>


<DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vogue & Chic - Product</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <!-- Top Header Bar -->

    <header class="top-bar">
       <div class="logo"><a href="HOME.php" class="logo-link">Vogue & Chic</a></div>
    </header>

    <!-- Product Section (Split Layout) -->
    <section class="product-section">

        <!-- Left Side: Product Details -->
        <div class="product-details">

            <!-- Wrapper div for better spacing -->
            <div class="product-info-top">
                <h1 class="product-title">Classic Denim Jacket</h1>
                <p class="product-price">Rs.2500</p>

                <div class="size-selector">
                    <p class="size-label">size:</p>
                    <div class="size-buttons">
                        <!-- Add the class "active" to whichever size is selected -->
                        <button class="size-btn">S</button>
                        <button class="size-btn">M</button>
                        <button class="size-btn">L</button>
                    </div>
                </div>
            </div>

            <!-- Action Buttons are outside the top wrapper -->
            <div class="action-buttons">
    <a href="add_to_cart.php?id=1" class="action-btn">Add to cart</a>
    <a href="CheckOut.php" class="action-btn">Checkout</a>
    
    <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
        <a href="edit_product.php?id=13" class="action-btn" style="background: blue;">Edit Product</a>
    <?php endif; ?>
</div>

        </div>

        <!-- Right Side: Product Image -->
        <div class="product-image-container">
            <!-- Replace the src below with your own jacket image -->
            <img src="https://cdn.discordapp.com/attachments/1565465227926044712/1565471405879853247/image.png?ex=6ae5065c&is=6ae3b4dc&hm=e08d7c26502ccde4ea8166c3d0bc0fdc9ba1c90a36caf0ea28b70e06a6b6f5bd&">
        </div>

    </section>

    <!-- Bottom Solid Color Section -->
    <section class="bottom-color-block">
        <!-- Content for the bottom area can go here -->
    </section>

</body>
</html>
?>