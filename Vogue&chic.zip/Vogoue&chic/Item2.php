<?php
session_start();
require 'config.php';

$id = 2; // ID for the Knit Shirt
$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vogue & Chic - Product</title>
    <link rel="stylesheet" href="Styles.css">
</head>
<body>

    <!-- Top Header Bar -->
    <header class="top-bar">
        <div class="logo"><a href="HOME.php" class="logo-link">Vogue & Chic</a></div>
    </header>

    <!-- Product Section (Split Layout) -->
    <section class="product-section">

        <!-- Left Side: Product Details -->
        <div class="product-details">

            <div class="product-info-top">
                <h1 class="product-title"><?php echo htmlspecialchars($product['name']); ?></h1>
                <p class="product-price">Rs.<?php echo $product['price']; ?></p>

                <div class="size-selector">
                    <p class="size-label">size:</p>
                    <div class="size-buttons">
                        <button class="size-btn">S</button>
                        <button class="size-btn">M</button>
                        <button class="size-btn">L</button>
                    </div>
                </div>
            </div>

            <!-- Action Buttons -->
            <div class="action-buttons">
                <a href="add_to_cart.php?id=2" class="action-btn">Add to cart</a>
                <a href="CheckOut.php" class="action-btn">Checkout</a>
            </div>

        </div>

        <!-- Right Side: Product Image -->
        <div class="product-image-container">
            <img src="https://media.discordapp.net/attachments/1565465227926044712/1565472444586660051/image.png?ex=6ae70193&is=6ae5b013&hm=a481beefe983c9c1c2cfd6297a075f2f1e0d4e850b2ee48e8ad4c20e22057568&=&format=webp&quality=lossless">
        </div>

    </section>

    <!-- Bottom Solid Color Section -->
    <section class="bottom-color-block">
    </section>

</body>
</html>