<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vogue & Chic - Product</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <!-- Top Header Bar -->
    <header class="top-bar">
        <div class="logo"><a href="HOME.php" class="logo-link">Vogue & Chic</a></div>
    </header>

    <!-- Product Section (Split Layout) -->
    <section class="product-section">

        <!-- Left Side: Product Details -->
        <div class="product-details">

            <!-- Wrapper div for better spacing -->
            <div class="product-info-top">
                <h1 class="product-title">Cargo Pants For Summer</h1>
                <p class="product-price">Rs.700</p>

                <div class="size-selector">
                    <p class="size-label">size:</p>
                    <div class="size-buttons">
                        <!-- Add the class "active" to whichever size is selected -->
                        <button class="size-btn">S</button>
                        <button class="size-btn">M</button>
                        <button class="size-btn">L</button>
                    </div>
                </div>
            </div>

            <!-- Action Buttons are outside the top wrapper -->
            <div class="action-buttons">
                <a href="#" class="action-btn">Add to cart</a>
                <a href="CheckOut.html" class="action-btn">Checkout</a>
            </div>

        </div>

        <!-- Right Side: Product Image -->
        <div class="product-image-container">
            <!-- Replace the src below with your own jacket image -->
            <img src="https://cdn.discordapp.com/attachments/1565465227926044712/1565476661892227092/image.png?ex=6ae50b41&is=6ae3b9c1&hm=2ce015910b4b5745d30beff97e578cbbb6a24c30ac709b42b07abdec8b50a314&">
        </div>

    </section>

    <!-- Bottom Solid Color Section -->
    <section class="bottom-color-block">
        <!-- Content for the bottom area can go here -->
    </section>

</body>
</html>