<?php
session_start();
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login | Vogue & Chic</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Alike&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="Styles.css">

</head>

<body class="login-page">
  <main class="login-card">

    <header class="brand">
      <h1>Vogue <span>&</span> Chic</h1>
      <p>Welcome back. Log in to continue your style journey.</p>
    </header>

    <form action="HOME.php" method="POST">

      <!-- Email -->
      <div class="form-group">
        <label for="email">Email Address</label>
        <input
          type="email"
          id="email"
          name="email"
          placeholder="you@example.com"
          autocomplete="email"
          required
        >
      </div>

      <!-- Password -->
      <div class="form-group">
        <label for="password">Password</label>

        <div class="password-wrap">
          <input
            type="password"
            id="password"
            name="password"
            placeholder="Enter your password"
            minlength="8"
            maxlength="13"
            autocomplete="current-password"
            required
          >

          <button
            type="button"
            class="toggle-password"
            id="togglePassword"
            aria-controls="password"
            aria-pressed="false"
          >Show</button>
        </div>
      </div>

      <button type="submit" class="login-btn">Login</button>

    </form>

    <p class="register-text">
      Don't have an account?
      <a href="register.html">Register here</a>
    </p>

  </main>

  <script>
    // Show or hide the password
    const password = document.getElementById("password");
    const toggle = document.getElementById("togglePassword");

    toggle.addEventListener("click", function () {
      const show = password.type === "password";

      password.type = show ? "text" : "password";
      toggle.textContent = show ? "Hide" : "Show";
      toggle.setAttribute("aria-pressed", String(show));
    });
  </script>

</body>
</html>