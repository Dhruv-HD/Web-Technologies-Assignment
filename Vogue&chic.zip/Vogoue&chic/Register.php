<?php
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    try {
        $stmt = $pdo->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
        $stmt->execute([$name, $email, $hashed_password]);
        echo "Registration successful! <a href='login.html'>Login here</a>";
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) {
            echo "Email already registered.";
        } else {
            echo "Error: " . $e->getMessage();
        }
    }
  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Register | Vogue & Chic</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Alike&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="Styles.css">

</head>

<body class="register-page">
  <main class="register-card">

    <header class="brand">
      <h1>Vogue <span>&</span> Chic</h1>
      <p>Create your account and join our world of style.</p>
    </header>

    <form action="HOME.html" method="POST">

      <!-- Full name -->
      <div class="form-group">
        <label for="name">Full Name</label>
        <input
          type="text"
          id="name"
          name="name"
          placeholder="Enter your full name"
          autocomplete="name"
          required
        >
      </div>

      <!-- Email -->
      <div class="form-group">
        <label for="email">Email Address</label>
        <input
          type="email"
          id="email"
          name="email"
          placeholder="you@example.com"
          autocomplete="email"
          required
        >
      </div>

      <!-- Password -->
      <div class="form-group">
        <label for="password">Password</label>

        <div class="password-wrap">
          <input
            type="password"
            id="password"
            name="password"
            placeholder="Create a strong password"
            minlength="8"
            maxlength="13"
            pattern="(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[^A-Za-z0-9\s]).{8,13}"
            title="Password must be between 8 and 13 characters with uppercase, lowercase, a number, and a special character."
            autocomplete="new-password"
            aria-describedby="password-hint"
            required
          >

          <button
            type="button"
            class="toggle-password"
            id="togglePassword"
            aria-controls="password"
            aria-pressed="false"
          >Show</button>
        </div>

        <small class="hint" id="password-hint">
          Use exactly 8 characters, including all four character types.
        </small>
      </div>

      <button type="submit" class="register-btn">Create Account</button>

    </form>

    <p class="login-text">
      Already have an account?
      <a href="Login.html">Log in here</a>
    </p>

  </main>

  <script>
    // Show or hide the password
    const password = document.getElementById("password");
    const toggle = document.getElementById("togglePassword");

    toggle.addEventListener("click", function () {
      const show = password.type === "password";

      password.type = show ? "text" : "password";
      toggle.textContent = show ? "Hide" : "Show";
      toggle.setAttribute("aria-pressed", String(show));
    });
  </script>

</body>
</html>