<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    die("Please login to add to cart. <a href='login.html'>Login here</a>");
}

if (isset($_GET['id'])) {
    $user_id = $_SESSION['user_id'];
    $product_id = $_GET['id'];

    $stmt = $pdo->prepare("SELECT * FROM cart WHERE user_id = ? AND product_id = ?");
    $stmt->execute([$user_id, $product_id]);
    $existing = $stmt->fetch();

    if ($existing) {
        $stmt = $pdo->prepare("UPDATE cart SET quantity = quantity + 1 WHERE id = ?");
        $stmt->execute([$existing['id']]);
    } else {
        $stmt = $pdo->prepare("INSERT INTO cart (user_id, product_id) VALUES (?, ?)");
        $stmt->execute([$user_id, $product_id]);
    }

    header("Location: products.php");
    exit;
}
?>