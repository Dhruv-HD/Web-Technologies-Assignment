<?php
session_start();
require 'config.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    die("Access Denied. You are not an admin.");
}

$stmt = $pdo->query("
    SELECT orders.id AS order_id, orders.status, orders.total, users.email, address.full_name, address.street_address 
    FROM orders 
    JOIN users ON orders.user_id = users.id 
    JOIN address ON orders.user_id = address.user_id 
    ORDER BY orders.created_at DESC
");
$orders = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin - Orders</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        th { background: #1A2A3A; color: white; }
    </style>
</head>
<body>
    <h2>Manage Customer Orders</h2>
    <a href="products.php">Back to Products</a>
    
    <table>
        <tr>
            <th>Order ID</th>
            <th>Customer Email</th>
            <th>Name</th>
            <th>Address</th>
            <th>Total</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        <?php foreach ($orders as $order): ?>
        <tr>
            <td><?php echo $order['order_id']; ?></td>
            <td><?php echo htmlspecialchars($order['email']); ?></td>
            <td><?php echo htmlspecialchars($order['full_name']); ?></td>
            <td><?php echo htmlspecialchars($order['street_address']); ?></td>
            <td>Rs <?php echo $order['total']; ?></td>
            <td><strong><?php echo $order['status']; ?></strong></td>
            <td>
                <form method="POST" action="update_status.php" style="display:inline;">
                    <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                    <select name="status">
                        <option value="Pending" <?php if($order['status'] == 'Pending') echo 'selected'; ?>>Pending</option>
                        <option value="Shipped" <?php if($order['status'] == 'Shipped') echo 'selected'; ?>>Shipped</option>
                        <option value="Delivered" <?php if($order['status'] == 'Delivered') echo 'selected'; ?>>Delivered</option>
                    </select>
                    <button type="submit">Update</button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>