<?php
require 'config.php';

$id = $_GET['id'];

// Delete the product using a prepared statement
$stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
$stmt->execute([$id]);

// Redirect back to products page
header("Location: products.php");
exit;
?>