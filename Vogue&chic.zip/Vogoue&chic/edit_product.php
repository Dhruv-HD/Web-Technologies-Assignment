<?php
session_start();
require 'config.php';

// Security Check: Only Admins can access this page
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    die("Access Denied. You are not an admin.");
}

// Get the product ID from the URL
$id = $_GET['id'];

// Fetch the specific product
$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product | Vogue & Chic</title>
    <link rel="stylesheet" href="Styles.css">
</head>
<body>

    <header class="top-bar">
        <div class="logo"><a href="HOME.php" class="logo-link">Vogue & Chic</a></div>
    </header>

    <main class="form-section" style="margin-top: 50px; background-color: #adacb0;">
        <h2 style="font-family: Georgia; text-align: center; margin-bottom: 20px;">Edit Product</h2>
        
        <form action="update_product.php" method="POST">
            <input type="hidden" name="id" value="<?php echo $product['id']; ?>">
            
            <div class="form-group">
                <label>Product Name:</label>
                <input type="text" name="name" value="<?php echo htmlspecialchars($product['name']); ?>" required>
            </div>

            <div class="form-group">
                <label>Price (Rs):</label>
                <input type="number" step="0.01" name="price" value="<?php echo $product['price']; ?>" required>
            </div>
            
            <div class="submit-container">
                <button type="submit">Update Product</button>
            </div>
        </form>
        
        <br>
        <div style="text-align: center;">
            <a href="HOME.php" style="text-decoration: underline; color: #333; font-family: Georgia;">Back to Home</a>
        </div>
    </main>

</body>
</html>