<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    die("Please login first. <a href='login.html'>Login here</a>");
}

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM address WHERE user_id = ? ORDER BY created_at DESC");
$stmt->execute([$user_id]);
$orders = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<body>
    <h2>My Orders - Vogue & Chic</h2>
    <p>Logged in as: <strong><?php echo htmlspecialchars($_SESSION['user_email'] ?? 'Customer'); ?></strong></p>
    <a href="products.php">Back to Shop</a>
    <br><br>
    <?php if (count($orders) > 0): ?>
        <table border="1" cellpadding="10">
            <tr>
                <th>Order ID</th>
                <th>Name</th>
                <th>Address</th>
                <th>City</th>
            </tr>
            <?php foreach ($orders as $order): ?>
            <tr>
                <td><?php echo $order['id']; ?></td>
                <td><?php echo htmlspecialchars($order['full_name']); ?></td>
                <td><?php echo htmlspecialchars($order['street_address']); ?></td>
                <td><?php echo htmlspecialchars($order['city']); ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p>You have no orders yet.</p>
    <?php endif; ?>
</body>
</html>