<?php
session_start();
require 'config.php';

if (!isset($_GET['id'])) {
    die("Product not found.");
}

$id = $_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch();

if (!$product) {
    die("Product not found.");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title><?php echo htmlspecialchars($product['name']); ?> - Vogue & Chic</title>
    <style>
        body { font-family: Arial; padding: 20px; background: #f5f5f5; }
        .container { max-width: 800px; margin: auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .product-image { width: 300px; height: 400px; object-fit: contain; float: left; margin-right: 30px; }
        .product-info { overflow: hidden; padding-top: 20px; }
        .price { color: #e74c3c; font-size: 28px; font-weight: bold; margin: 15px 0; }
        .btn { display: inline-block; padding: 12px 25px; text-decoration: none; color: white; border-radius: 5px; font-weight: bold; margin-right: 10px; }
        .btn-cart { background: #1A2A3A; }
        .btn-buy { background: green; }
        .back-link { display: block; margin-bottom: 20px; color: #1A2A3A; text-decoration: none; font-weight: bold; }
    </style>
</head>
<body>
    <div class="container">
        <a href="products.php" class="back-link">← Back to Shop</a>
        
        <img src="<?php echo htmlspecialchars($product['image_url']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="product-image">
        
        <div class="product-info">
            <h1><?php echo htmlspecialchars($product['name']); ?></h1>
            <p style="color: #666; margin-top: 10px;"><?php echo htmlspecialchars($product['description']); ?></p>
            <p class="price">Rs <?php echo number_format($product['price'], 2); ?></p>
            
            <br><br>
            <a href="add_to_cart.php?id=<?php echo $product['id']; ?>" class="btn btn-cart">Add to Cart</a>
            <a href="checkout_address.php" class="btn btn-buy">Buy Now</a>
        </div>
    </div>
</body>
</html>