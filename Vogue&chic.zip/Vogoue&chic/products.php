<?php
session_start();
require 'config.php';

$stmt = $pdo->query("SELECT * FROM products");
$products = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vogue & Chic - Product</title>
    <link rel="stylesheet" href="Styles.css">
</head>
<body>
    <h1>Vogue & Chic</h1>

    <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
        <div style="margin-bottom: 20px;">
            <a href="admin_orders.php" style="background: #ff9800; color: white; padding: 10px; text-decoration: none; border-radius: 4px; font-weight: bold;">View Customer Orders</a>
        </div>
    <?php endif; ?>

    <div style="margin-bottom: 20px;">
        <a href="contact_new.php" style="text-decoration: none; color: #1A2A3A; font-weight: bold; margin-right: 15px;">Contact Us</a>
    </div>

    <?php if (isset($_SESSION['user_name'])): ?>
        <p>Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?>! | <a href="logout.php">Logout</a></p>
    <?php else: ?>
        <p><a href="login.php">Login</a> | <a href="register.php">Register</a></p>
    <?php endif; ?>

    <a href="checkout_address.php" style="background: green; color: white; padding: 10px; text-decoration: none; display: inline-block; margin-bottom: 20px;">Proceed to Checkout</a>
    <a href="view_cart.php" style="background: #ff9800; color: white; padding: 10px; text-decoration: none; display: inline-block; margin-bottom: 20px;">View Cart</a>
    <a href="my_orders.php" style="background: #1A2A3A; color: white; padding: 10px; text-decoration: none; display: inline-block; margin-bottom: 20px;">My Orders</a>

    <div class="product-grid">
        <?php foreach ($products as $product): ?>
            <div class="product-card">
                <a href="product_detail.php?id=<?php echo $product['id']; ?>">
                    <img src="<?php echo htmlspecialchars($product['image_url']); ?>" alt="Product">
                </a>
                <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                <p><?php echo htmlspecialchars($product['description']); ?></p>
                <p class="price">Rs <?php echo number_format($product['price'], 2); ?></p>

                <a href="add_to_cart.php?id=<?php echo $product['id']; ?>" style="background: #1A2A3A; color: white; padding: 8px 15px; text-decoration: none; border-radius: 4px; display: inline-block; margin-top: 10px;">Add to Cart</a>

                <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                    <a href="edit_product.php?id=<?php echo $product['id']; ?>" style="display:inline-block; margin-top:10px; background:blue; color:white; padding:5px; text-decoration:none;">Edit Product</a>
                    <a href="delete_product.php?id=<?php echo $product['id']; ?>" style="display:inline-block; margin-top:10px; background:red; color:white; padding:5px; text-decoration:none;" onclick="return confirm('Are you sure?');">Delete</a>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>