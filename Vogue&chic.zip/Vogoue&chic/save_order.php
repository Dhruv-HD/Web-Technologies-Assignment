<?php
session_start();
require 'config.php';

/**
 * Show an error inside the same styled page as the checkout, then stop.
 */
function showError(string $message, string $backLink = 'checkout.php'): void
{
    http_response_code(400);
    $safeMessage = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');
    $safeLink    = htmlspecialchars($backLink, ENT_QUOTES, 'UTF-8');
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Problem | Vogue and Chic Boutique</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Alike&display=swap">
    <link rel="stylesheet" href="Styles.css">
</head>
<body class="checkout-page">
    <div class="site-header">Vogue &amp; Chic</div>
    <div class="checkout">
        <h1>Oops!</h1>
        <p class="message"><?= $safeMessage ?></p>
        <a class="back-btn" href="<?= $safeLink ?>">Back to checkout</a>
    </div>
</body>
</html>
    <?php
    exit;
}

if (!isset($_SESSION['user_id'])) {
    header('Location: login.html');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: checkout.php');
    exit;
}

// Validate the form security token
$token = $_POST['csrf_token'] ?? '';

if (
    empty($_SESSION['csrf_token']) ||
    !is_string($token) ||
    !hash_equals($_SESSION['csrf_token'], $token)
) {
    showError('Invalid request. Please return to checkout and try again.');
}

// Read shipping details
$fullName      = trim($_POST['full_name'] ?? '');
$phone         = trim($_POST['phone'] ?? '');
$address       = trim($_POST['address'] ?? '');
$city          = trim($_POST['city'] ?? '');
$postalCode    = trim($_POST['postal_code'] ?? '');
$paymentMethod = $_POST['payment_method'] ?? '';

if (
    $fullName === '' || $phone === '' ||
    $address === '' || $city === '' ||
    $postalCode === ''
) {
    showError('Please complete all shipping fields.');
}

if (
    mb_strlen($fullName) > 100 || mb_strlen($phone) > 30 ||
    mb_strlen($address) > 255 || mb_strlen($city) > 100 ||
    mb_strlen($postalCode) > 20
) {
    showError('One or more fields are too long.');
}

// Same rules as the checkout page: letters only for names, digits for phone
if (!preg_match("/^[\p{L}\s'.\-]+$/u", $fullName)) {
    showError('Name can only contain letters, no numbers.');
}

if (!preg_match('/^[0-9+\s()\-]+$/', $phone)) {
    showError('Phone number can only contain digits, not letters.');
}

$phoneDigits = strlen(preg_replace('/\D/', '', $phone));
if ($phoneDigits < 7 || $phoneDigits > 15) {
    showError('Please enter a valid phone number (7 to 15 digits).');
}

if (!preg_match("/^[\p{L}\s'.\-]+$/u", $city)) {
    showError('City can only contain letters, no numbers.');
}

if (!preg_match('/^[A-Za-z0-9\s\-]+$/', $postalCode)) {
    showError('Postal code can only contain letters and numbers.');
}

// "demo" is replaced by "card"
if (!in_array($paymentMethod, ['cod', 'card'], true)) {
    showError('Invalid payment method.');
}

// Get cart from the server-side session
$cart = $_SESSION['cart'] ?? [];

if (empty($cart)) {
    showError('Your cart is empty. Please add a product first.', 'index.html');
}

try {
    $pdo->beginTransaction();

    $productStmt = $pdo->prepare(
        'SELECT id, price FROM products WHERE id = ?'
    );

    $subtotal = 0;

    foreach ($cart as $productId => $quantity) {
        $productId = filter_var($productId, FILTER_VALIDATE_INT);
        $quantity  = filter_var($quantity, FILTER_VALIDATE_INT);

        if (
            !$productId || !$quantity ||
            $quantity < 1 || $quantity > 10
        ) {
            throw new Exception('Invalid cart quantity.');
        }

        $productStmt->execute([$productId]);
        $product = $productStmt->fetch();

        if (
            !$product || !is_numeric($product['price']) ||
            $product['price'] < 0
        ) {
            throw new Exception('A cart product is unavailable.');
        }

        $subtotal += (float)$product['price'] * $quantity;
    }

    // Delivery rule: free when subtotal is Rs 2,000 or more
    $deliveryFee = ($subtotal >= 2000) ? 0 : 100;
    $total = $subtotal + $deliveryFee;

    // Both start as "pending". Card payments are not processed on this site,
    // so nothing is marked as paid until a real payment gateway confirms it.
    $paymentStatus = 'pending';

    $sql = "INSERT INTO orders
        (user_id, full_name, phone, address, city, postal_code,
         payment_status, subtotal, delivery_fee, total,
         payment_method, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $_SESSION['user_id'],
        $fullName,
        $phone,
        $address,
        $city,
        $postalCode,
        $paymentStatus,
        $subtotal,
        $deliveryFee,
        $total,
        $paymentMethod
    ]);

    $orderId = $pdo->lastInsertId();
    $pdo->commit();

    $_SESSION['last_order_id']       = $orderId;
    $_SESSION['last_order_total']    = $total;
    $_SESSION['last_order_delivery'] = $deliveryFee;
    $_SESSION['order_placed']        = true;   // lets thank_you.php open

    unset($_SESSION['cart'], $_SESSION['csrf_token']);

    header('Location: thank_you.php');
    exit;

} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    error_log($e->getMessage());
    showError('Unable to place your order. Please check your cart and try again.');
}