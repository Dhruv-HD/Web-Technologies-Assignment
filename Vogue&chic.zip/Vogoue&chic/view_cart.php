<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    die("Please login. <a href='login.html'>Login here</a>");
}

$user_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("
    SELECT cart.id AS cart_id, cart.quantity, products.name, products.price 
    FROM cart 
    JOIN products ON cart.product_id = products.id 
    WHERE cart.user_id = ?
");
$stmt->execute([$user_id]);
$cart_items = $stmt->fetchAll();

$total = 0;
?>

<!DOCTYPE html>
<html>
<body>
    <h2>Your Shopping Cart</h2>
    <a href="products.php">Continue Shopping</a>
    <br><br>

    <?php if (count($cart_items) > 0): ?>
        <table border="1" cellpadding="10">
            <tr>
                <th>Product</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Subtotal</th>
            </tr>
            <?php foreach ($cart_items as $item): ?>
                <?php $subtotal = $item['price'] * $item['quantity']; $total += $subtotal; ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['name']); ?></td>
                    <td>Rs <?php echo $item['price']; ?></td>
                    <td><?php echo $item['quantity']; ?></td>
                    <td>Rs <?php echo $subtotal; ?></td>
                </tr>
            <?php endforeach; ?>
            <tr>
                <td colspan="3" align="right"><strong>Total:</strong></td>
                <td><strong>Rs <?php echo $total; ?></strong></td>
            </tr>
        </table>
        <br>
        <a href="checkout_address.php" style="background: green; color: white; padding: 10px; text-decoration: none;">Proceed to Checkout</a>
    <?php else: ?>
        <p>Your cart is empty.</p>
    <?php endif; ?>
</body>
</html>