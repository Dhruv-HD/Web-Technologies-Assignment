-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 31, 2026 at 08:45 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vogue_and_chic_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `street_address` varchar(255) NOT NULL,
  `city` varchar(100) NOT NULL,
  `postal_code` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `product_name` varchar(255) NOT NULL,
  `product_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`id`, `user_id`, `full_name`, `phone`, `street_address`, `city`, `postal_code`, `created_at`, `product_name`, `product_id`) VALUES
(1, 1, 'Paul Sameul', '5845 1234', 'Bel air', 'Flacq', '123456', '2026-10-30 02:15:12', '', NULL),
(2, 1, 'Paul Sameul', '5020 1234', 'Bel air', 'Flacq', '1234567', '2026-10-30 02:19:51', '', NULL),
(3, 1, 'yash', '5802 4520', 'port louis', 'pailles', '145236', '2026-10-30 02:22:01', '', NULL),
(4, 1, 'Chetna Devi Soobaruth', '58028016', 'solferino no 3', 'vacoas', '123456789', '2026-10-30 02:28:39', '', NULL),
(5, 4, 'kesh', '5020 5426', 'Bel air', 'quartier', '1234568', '2026-10-30 02:31:58', '', NULL),
(6, 4, 'Paul Sameul', '50201234', 'Bel air', 'Flacq', '1234567', '2026-10-30 02:38:54', 'Vogue & Chic Summer Collection', NULL),
(7, 1, 'Paul Sameul', '50201234', 'Bel air', 'Flacq', '1234567', '2026-10-30 03:01:42', 'Vogue & Chic Summer Collection', NULL),
(8, 1, 'mariss', '54628515', 'cpe', 'cpe', '4521', '2026-10-30 03:02:18', 'Vogue & Chic Summer Collection', NULL),
(9, 1, 'mariss', '54628515', 'cpe', 'cpe', '4521', '2026-10-30 03:02:37', 'Vogue & Chic Summer Collection', NULL),
(10, 12, 'Chetna Devi Soobaruth', '58028016', 'solferino no 3', 'vacoas', '123456789', '2026-10-30 03:11:18', 'Mens Knit Short Sleeve Shirt', 2),
(11, 12, 'Chetna Devi Soobaruth', '58028016', 'solferino no 3', 'vacoas', '123456789', '2026-10-30 03:16:02', 'Mens Knit Short Sleeve Shirt', 2),
(12, 14, 'Chetna Devi Soobaruth', '58028016', 'solferino no 3', 'vacoas', '123456789', '2026-10-30 18:39:01', 'Mens Knit Short Sleeve Shirt', 2);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `product_id`, `quantity`, `created_at`) VALUES
(1, 1, 2, 4, '2026-10-30 03:01:26'),
(2, 12, 2, 3, '2026-10-30 03:11:07'),
(3, 14, 2, 1, '2026-10-30 18:38:08');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `address` text NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(50) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `address`, `total`, `created_at`, `status`) VALUES
(1, 1, 'solferino', 2500.00, '2026-10-30 00:54:27', ''),
(2, 1, 'vacoas', 2500.00, '2026-10-30 00:56:47', ''),
(3, 1, 'Name: Chetna Devi Soobaruth, Phone: 58028016, Address: solferino no 3, City: vacoas, Postal: 123456789', 2500.00, '2026-10-30 01:17:05', 'Pending'),
(4, 1, 'Name: Chetna Devi Soobaruth, Phone: 58028016, Address: solferino no 3, City: vacoas, Postal: 123456789', 2500.00, '2026-10-30 01:17:57', 'Shipped'),
(5, 12, 'Name: Chetna Devi Soobaruth, Phone: 58028016, Address: solferino no 3, City: vacoas, Postal: 123456789', 1200.00, '2026-10-30 03:16:02', 'Pending'),
(6, 14, 'Name: Chetna Devi Soobaruth, Phone: 58028016, Address: solferino no 3, City: vacoas, Postal: 123456789', 1200.00, '2026-10-30 18:39:01', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `image_url` varchar(500) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `stock` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `image_url`, `category`, `stock`, `created_at`) VALUES
(2, 'Mens Knit Short Sleeve Shirt', 'Comfortable knit shirt for casual wear', 1200.00, 'knitshirt.png', 'Shirts', 15, '2026-10-26 20:09:23'),
(3, 'Womens Maxi Dress', 'Elegant maxi dress for summer', 1500.00, 'maxidress.png', 'Dresses', 8, '2026-10-26 20:09:23'),
(4, 'Mens Linen Shorts', 'Breathable linen shorts for hot days', 600.00, 'linenshort.png', 'Shorts', 20, '2026-10-26 20:09:23'),
(5, 'Kids Jumpsuit', 'Cute and comfortable jumpsuit for kids', 800.00, 'kidsjumpsuit.png', 'Kids', 12, '2026-10-26 20:09:23'),
(12, 'Cargo Pants for Summer', 'Stylish cargo pants with multiple pockets', 700.00, 'cargopant.png', 'Pants', 18, '2026-10-29 23:54:25'),
(13, 'Classic Denim Jacket', 'Timeless denim jacket for all seasons', 2500.00, 'jacket.png', 'Jackets', 10, '2026-10-29 23:57:36');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('customer','admin') DEFAULT 'customer',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `created_at`) VALUES
(1, 'Test user', 'test@test.com', '$2y$10$q3ulV67ILv0aSQXKC/YJzObj0fvxBEl1czIHgvEJ3P/dzwQl2mpHu', 'customer', '2026-10-27 22:22:28'),
(3, 'Admin ', 'admin@test.com', '$2y$10$qC3IXyfqynh5PBBaugmS1uOd0GTA8QQNNhlUV6ZwCxmhBJsNxQ/1u', 'admin', '2026-10-27 22:23:53'),
(4, 'Test2', 'test2@gmail.com', '$2y$10$IGk4xklSmDutPGRTLCQuV.PeE6vQMOFNfVuMjbzCUQNUcbgqNL1zq', 'customer', '2026-10-28 00:05:09'),
(10, 'Mrs Dhruv', 'dhruv@outlook.com', '$2y$10$hiFCvN.zGuYNe.7VeVD06Of8bXlHq4aQdftzFUrmx60Wpw6KZUsNS', 'customer', '2026-10-28 19:22:34'),
(11, 'customer', 'cus@test.com', '$2y$10$L8sY6bgBMZP/nFYgfR1W2.BO5uScjsnAeZlQSphvNhzg1oF97hFii', 'customer', '2026-10-30 00:14:59'),
(12, 'chetna', 'chetna@gmail.com', '$2y$10$huTY/nucMpqlvJHbPulGP.ARoMxcsvnPIzQ6KyRPollSnbsB8IHgW', 'customer', '2026-10-30 03:10:50'),
(14, 'Chetna Devi Soobaruth', 'chetna1@gmail.com', '$2y$10$crLsMYJWiROVCkvTnkkGUOw.1QIdUrtlYlefQxgEgwGPzbROHFlSm', 'customer', '2026-10-30 18:31:32');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
